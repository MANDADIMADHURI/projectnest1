def toggle_binary(binary_str):
    return ''.join(['1' if bit == '0' else '0' for bit in binary_str])

def play_game(arr, rahul_ab, rupesh_ab, k):
    while arr:
        max_index = arr.index(max(arr[max(0, max_index - k):min(len(arr), max_index + k + 1)]))
        selected_values = arr[max(0, max_index - k):min(len(arr), max_index + k + 1)]
        del arr[max(0, max_index - k):min(len(arr), max_index + k + 1)]
        
        if arr:
            max_index = arr.index(max(arr[max(0, max_index - k):min(len(arr), max_index + k + 1)]))

        if arr:
            selected_values += arr[max(0, max_index - k):min(len(arr), max_index + k + 1)]
            del arr[max(0, max_index - k):min(len(arr), max_index + k + 1)]

        if arr:
            max_index = arr.index(max(arr[max(0, max_index - k):min(len(arr), max_index + k + 1)]))

        if arr:
            selected_values += arr[max_index]

        if arr:
            del arr[max_index]

        if arr:
            rahul_ab[0] = toggle_binary(rahul_ab[0])
            rupesh_ab[0] = toggle_binary(rupesh_ab[0])

    rahul_sum = sum(selected_values for selected_values, player_ab in zip([selected_values], [rahul_ab, rupesh_ab]) if player_ab[1] == '1')
    rupesh_sum = sum(selected_values for selected_values, player_ab in zip([selected_values], [rahul_ab, rupesh_ab]) if player_ab[1] == '0')

    if rahul_sum > rupesh_sum:
        return "Rahul"
    elif rupesh_sum > rahul_sum:
        return "Rupesh"
    else:
        return "Both"

# Input reading
arr = list(map(int, input().split()))
rahul_ab = input().split()
rupesh_ab = input().split()
k = int(input())

# Game result
result = play_game(arr, rahul_ab, rupesh_ab, k)
print(result)
